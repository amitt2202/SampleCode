package state.ma.us.OMSBulk.vo;

import java.io.Serializable;

public class OrganizationVO  implements Serializable{
    private String orgId;
    private String legalName;
    private String vgOrgId;
    private String parentVGOrgId;
    private String orgType;
    private String orgStatus;
    private String orgURL;
    private Boolean isValidorg;
    

    private String addLine1;
    private String addLine2;
    private String city;
    private String zip;
    private String state;
    
    
	
	public String getAddLine1() {
		return addLine1;
	}
	public void setAddLine1(String addLine1) {
		this.addLine1 = addLine1;
	}
	public String getAddLine2() {
		return addLine2;
	}
	public void setAddLine2(String addLine2) {
		this.addLine2 = addLine2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Boolean getIsValidorg() {
		return isValidorg;
	}
	public void setIsValidorg(Boolean isValidorg) {
		this.isValidorg = isValidorg;
	}
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	public String getLegalName() {
		return legalName;
	}
	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}
	public String getVgOrgId() {
		return vgOrgId;
	}
	public void setVgOrgId(String vgOrgId) {
		this.vgOrgId = vgOrgId;
	}
	public String getParentVGOrgId() {
		return parentVGOrgId;
	}
	public void setParentVGOrgId(String parentVGOrgId) {
		this.parentVGOrgId = parentVGOrgId;
	}
	public String getOrgType() {
		return orgType;
	}
	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}
	public String getOrgStatus() {
		return orgStatus;
	}
	public void setOrgStatus(String orgStatus) {
		this.orgStatus = orgStatus;
	}
	public String getOrgURL() {
		return orgURL;
	}
	public void setOrgURL(String orgURL) {
		this.orgURL = orgURL;
	}

}
