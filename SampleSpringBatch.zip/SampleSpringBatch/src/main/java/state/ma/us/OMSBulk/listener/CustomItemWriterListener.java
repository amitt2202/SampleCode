package state.ma.us.OMSBulk.listener;


import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.batch.core.ItemWriteListener;

import state.ma.us.OMSBulk.vo.OrganizationVO;
public class CustomItemWriterListener implements ItemWriteListener<OrganizationVO> {

	@Override
	public void beforeWrite(List<? extends OrganizationVO> items) {
		ArrayList ar=new ArrayList(items);
		//System.out.println("ItemWriteListener - beforeWrite");
	}

	@Override
	public void afterWrite(List<? extends OrganizationVO> items) {
		ArrayList ar=new ArrayList(items);
		ArrayList<OrganizationVO> validList=new ArrayList<OrganizationVO>();
		ArrayList<OrganizationVO> inValidList=new ArrayList<OrganizationVO>();
		for(Object or:ar){
			OrganizationVO o=(OrganizationVO) or;
			if(o.getIsValidorg()){
				validList.add(o);
			}else{
				inValidList.add(o);
			}
		}
		/*System.out.println("ItemWriteListener - afterWrite :  Valid orgs");
		for(OrganizationVO o:validList){
			System.out.println(o.getLegalName());
		}
		System.out.println("ItemWriteListener - afterWrite :  InValid orgs");
		for(OrganizationVO o:inValidList){
			System.out.println(o.getLegalName());
		}*/
		publishEMail(validList,inValidList);
	}

	private void publishEMail(ArrayList<OrganizationVO> validList,
			ArrayList<OrganizationVO> inValidList) {
		boolean isPublishEmail = false;
		String emailBody=contructEmail(validList,inValidList);
		System.out.println(emailBody);
		try {
			String host = "itd-smtp-extapp.state.ma.us";
			String debug = "false";

			Properties props = new Properties();
			props.put("mail.host", host);
			props.put("mail.smtp.host", host);
			props.put("mail.debug", debug);
			// props.put("mail.smtp.port", "256");

			// Session session = Session.getInstance(props, new MyAuth());
			Session session = Session.getDefaultInstance(props, null);
			session.setDebug(true);

			System.out.println("got the mail session. session=" + session);

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("Etest@gmail.com"));
			message.setRecipient(Message.RecipientType.TO, new InternetAddress("amitt.ranjan@gmail.com"));
			message.setSubject("Bulk Job Report");
			message.setContent(emailBody, "text/html");
			//Transport.send(message);

			isPublishEmail = true;
		} catch (Exception ex) {
			StringWriter sw = new StringWriter();
			ex.printStackTrace(new PrintWriter(sw));
			String stacktrace = sw.toString();
			System.out.println("Exception occured while publishing email " + stacktrace);
			
		}
		
	}

	private String contructEmail(ArrayList<OrganizationVO> validList, ArrayList<OrganizationVO> inValidList) {
		StringBuilder retStr=new StringBuilder("OMS bulk was processed at and following organizations were successfully created in OMS \n");
		for(int i=1; i<=validList.size();i++){
			OrganizationVO o=validList.get(i-1);
			retStr.append(i+" Organization Name : "+o.getLegalName()+"\n");
		}
		retStr.append(" Following organization could not get created due to error \n");
		for(int i=1; i<=inValidList.size();i++){
			OrganizationVO o=inValidList.get(i-1);
			retStr.append(i+" Organization Name : "+o.getLegalName()+"\n");
		}
		return retStr.toString();
	}

	@Override
	public void onWriteError(Exception exception, List<? extends OrganizationVO> items) {
		System.out.println("ItemWriteListener - onWriteError");
	}


}
