package state.ma.us.OMSBulk.util;

import state.ma.us.OMSBulk.vo.OrganizationVO;

public interface OMSDaoInterface {
	public String determineOrgType(String orgType);
	public String determineOrgStatus(String orgStatus);
	public String getOrgIdFromSequence();
	public String getOrgIdFromEHSId(String vgOrgId);
	public String createOrganization(OrganizationVO orgVO);
	public String updateOrganization(OrganizationVO orgVO);
	public String createInvalidOrganization(OrganizationVO orgVO);
}
