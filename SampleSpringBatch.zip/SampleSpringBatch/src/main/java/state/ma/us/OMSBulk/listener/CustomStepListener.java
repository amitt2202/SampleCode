package state.ma.us.OMSBulk.listener;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;

public class CustomStepListener implements StepExecutionListener {

	@Override
	public void beforeStep(StepExecution stepExecution) {
		System.out.println("************CustomStepListener - beforeStep************");
		String name = stepExecution.getStepName();
		System.out.println("*********CustomStepListener   name: " + name+" Id "+stepExecution.getId());
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		System.out.println("************CustomStepListener - afterStep************");
		return null;
	}

}
