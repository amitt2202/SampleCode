package state.ma.us.OMSBulk.util;

import java.util.Date;

import org.springframework.jdbc.core.JdbcTemplate;

import state.ma.us.OMSBulk.vo.OrganizationVO;

public class OMSDaoImpl implements OMSDaoInterface {
	private final String SQL_NEXTVAL_ORG_IDS_SEQ = "select ORG_IDS_SEQ.NEXTVAL from dual";
	private final String SQL_determineOrgType = "SELECT ORG_TYPE_ID FROM ORG_REGISTER_TYPE WHERE UPPER(ORG_TYPE_NAME) = ?";
	private final String SQL_determineOrgStatus = "SELECT ID FROM ORG_MANAGEMENT_STATUS WHERE UPPER(STATUS) = ?";

	private final String SQL_getOrgIdFromEHSId = "SELECT ORGID FROM BATCH_VALID_ORG WHERE EHSORGID=?";
	private final String SQL_CREATE_ORGANIZATION_VALID = "INSERT INTO BATCH_VALID_ORG(ORGID,ORGNAME,EHSORGID,PARENTEHSID,ORGTYPE,ORGSTATUS,WEBSITE,CREATED_DATE) VALUES (:ORGID,:ORGNAME,:EHSORGID,:PARENTEHSID,:ORGTYPE,:ORGSTATUS,:WEBSITE,:CREATED_DATE)";
	private final String SQL_CREATE_ORGANIZATION_INVALID = "INSERT INTO BATCH_INVALID_ORG(ORGNAME,EHSORGID,PARENTEHSID,ORGTYPE,ORGSTATUS,WEBSITE,CREATED_DATE) VALUES (:ORGNAME,:EHSORGID,:PARENTEHSID,:ORGTYPE,:ORGSTATUS,:WEBSITE,:CREATED_DATE)";
	private final String SQL_CREATE_ADDRESS = "INSERT INTO BATCH_VALID_ADDRESS(ORGID,ADDRESSLINE1,ADDRESSLINE2,CITY,ZIP,STATE) VALUES (:ORGID,:ADDRESSLINE1,:ADDRESSLINE2,:CITY,:ZIP,:STATE)";
	private final String SQL_UPDATE_ORGANIZATION = "UPDATE BATCH_VALID_ORG SET ORGNAME=:ORGNAME,PARENTEHSID=:PARENTEHSID,ORGTYPE=:ORGTYPE,ORGSTATUS=:ORGSTATUS,WEBSITE=:WEBSITE, UPDATED_DATE=:UPDATED_DATE WHERE EHSORGID=:EHSORGID";
	private final String SQL_UPDATE_ADDRESS = "UPDATE BATCH_VALID_ADDRESS SET ADDRESSLINE1=:ADDRESSLINE1,ADDRESSLINE2=:ADDRESSLINE2,CITY=:CITY,ZIP=:ZIP,STATE=:STATE WHERE  ORGID=:ORGID";
	
	private JdbcTemplate jdbcTemplate = null;

	public OMSDaoImpl() {

	}

	public OMSDaoImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public String determineOrgType(String orgType) {
		// System.out.println("determineOrgType:: Processing..." + orgType);
		String retStr = "";
		retStr = jdbcTemplate.queryForObject(SQL_determineOrgType,
				new Object[] { orgType.toUpperCase() }, String.class) == null ? ""
				: jdbcTemplate.queryForObject(SQL_determineOrgType,
						new Object[] { orgType.toUpperCase() }, String.class);
		// System.out.println("determineOrgType:: returning..." + retStr);
		return retStr;
	}

	@Override
	public String determineOrgStatus(String orgStatus) {
		// System.out.println("determineOrgStatus:: Processing..." +
		// orgStatus+" Upper case is "+orgStatus.toUpperCase());
		String retStr = "";
		retStr = jdbcTemplate.queryForObject(SQL_determineOrgStatus,
				new Object[] { orgStatus.toUpperCase() }, String.class) == null ? ""
				: jdbcTemplate.queryForObject(SQL_determineOrgStatus,
						new Object[] { orgStatus.toUpperCase() }, String.class);
		// System.out.println("determineOrgStatus:: returning..." + retStr);
		return retStr;
	}

	@Override
	public String getOrgIdFromSequence() {
		int retInt = 0;
		retInt = jdbcTemplate.queryForObject(SQL_NEXTVAL_ORG_IDS_SEQ,
				new Object[] {}, Integer.class);
		System.out.println("getOrgIdFromSequence:: returning..." + retInt);
		return retInt + "";
	}

	@Override
	public String getOrgIdFromEHSId(String vgOrgId) {
		System.out.println("getOrgIdFromEHSId:: Processing..." + vgOrgId);
		String retStr = "";
		retStr = (jdbcTemplate.queryForObject(SQL_getOrgIdFromEHSId,
				new Object[] { vgOrgId }, String.class) == null ? ""
				: jdbcTemplate.queryForObject(SQL_getOrgIdFromEHSId,
						new Object[] { vgOrgId }, String.class));
		System.out.println("getOrgIdFromEHSId:: returning..." + retStr);
		return retStr;
	}

	@Override
	public String createOrganization(OrganizationVO orgVO) {
		System.out.println("createOrganization:: Processing..."
				+ orgVO.getLegalName());
		String retStr = "";
		Date d = new Date();
		int orgResult = jdbcTemplate.update(SQL_CREATE_ORGANIZATION_VALID,
				orgVO.getOrgId(), orgVO.getLegalName(), orgVO.getVgOrgId(),
				orgVO.getParentVGOrgId(), orgVO.getOrgType(),
				orgVO.getOrgStatus(), orgVO.getOrgURL(), d);
		
		int addResult = jdbcTemplate.update(SQL_CREATE_ADDRESS,
				orgVO.getOrgId(), orgVO.getAddLine1(), orgVO.getAddLine2(),
				orgVO.getCity(), orgVO.getZip(),
				orgVO.getState());
		
		if (orgResult != 0 & addResult != 0) {
			retStr = "Org Creation Success";
		} else {
			retStr = "Org Creation Failure";
		}
		System.out.println("createOrganization:: returning..." + retStr);
		return retStr;
	}

	@Override
	public String updateOrganization(OrganizationVO orgVO) {
		System.out.println("updateOrganization:: Processing..."
				+ orgVO.getLegalName());
		String retStr = "";
		Date d = new Date();
		int orgResult = jdbcTemplate.update(SQL_UPDATE_ORGANIZATION,
				orgVO.getLegalName(), orgVO.getParentVGOrgId(),
				orgVO.getOrgType(), orgVO.getOrgStatus(), orgVO.getOrgURL(),
				d, orgVO.getVgOrgId());

		int addResult = jdbcTemplate.update(SQL_UPDATE_ADDRESS,
				orgVO.getAddLine1(), orgVO.getAddLine2(),
				orgVO.getCity(), orgVO.getZip(), orgVO.getState(),
				orgVO.getOrgId());
		if (orgResult != 0 & addResult != 0) {
			retStr = "Org Updation Success";
		} else {
			retStr = "Org Updation Failure";
		}
		System.out.println("updateOrganization:: returning..." + retStr);
		return retStr;
	}

	@Override
	public String createInvalidOrganization(OrganizationVO orgVO) {
		System.out.println("createInvalidOrganization:: Processing..."
				+ orgVO.getLegalName());
		String retStr = "";
		Date d = new Date();
		int orgResult = jdbcTemplate.update(SQL_CREATE_ORGANIZATION_INVALID,
				orgVO.getLegalName(), orgVO.getVgOrgId(),
				orgVO.getParentVGOrgId(), orgVO.getOrgType(),
				orgVO.getOrgStatus(), orgVO.getOrgURL(), d);
		if (orgResult != 0) {
			retStr = " createInvalidOrganization Success";
		} else {
			retStr = "createInvalidOrganization Failure";
		}
		System.out.println("createInvalidOrganization:: returning..." + retStr);
		return retStr;
	}

}
