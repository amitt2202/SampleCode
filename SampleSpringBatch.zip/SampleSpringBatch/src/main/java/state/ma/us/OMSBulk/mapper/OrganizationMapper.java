package state.ma.us.OMSBulk.mapper;



import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.validation.BindException;

import state.ma.us.OMSBulk.util.OMSDaoImpl;
import state.ma.us.OMSBulk.util.OMSDaoInterface;
import state.ma.us.OMSBulk.vo.OrganizationVO;






public class OrganizationMapper implements FieldSetMapper<OrganizationVO> {
	private JdbcTemplate jdbcTemplate;  

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	}
	
	@Override
	public OrganizationVO mapFieldSet(FieldSet fieldSet) throws BindException {
		OMSDaoInterface oui= new OMSDaoImpl(jdbcTemplate);
		OrganizationVO org = new OrganizationVO();
		
		org.setLegalName(fieldSet.readString(0));
		org.setVgOrgId(fieldSet.readString(1));
		org.setParentVGOrgId(fieldSet.readString(2));
		org.setOrgType(oui.determineOrgType(fieldSet.readString(3)));
		org.setOrgStatus(oui.determineOrgStatus(fieldSet.readString(4)));
		org.setOrgURL(fieldSet.readString(5));
		org.setAddLine1(fieldSet.readString(6));	
		org.setCity(fieldSet.readString(7));	
		org.setZip(fieldSet.readString(8));	
		org.setState(fieldSet.readString(9));	
		org=validateOrganization(org);
		return org;
		
	}

	private OrganizationVO validateOrganization(OrganizationVO org) {
		//System.out.println(org.getLegalName());
		if(org.getLegalName().toUpperCase().contains("ABC")){
			org.setIsValidorg(false);
		}else{
			org.setIsValidorg(true);
		}
		return org;
	}

}
