package state.ma.us.OMSBulk.processor;

import org.springframework.batch.item.ItemProcessor;

import state.ma.us.OMSBulk.vo.OrganizationVO;



public class OrgItemProcessor implements ItemProcessor<OrganizationVO, OrganizationVO> {

	@Override
	public OrganizationVO process(OrganizationVO item) throws Exception {
		
		System.out.println("OrgItemProcessor::Processing..." + item+" :: Legal Name: "+item.getLegalName());
		//if(validateRecord(item)){
			return item;			
		//}else{
			//return null;
		//}
	}

}
