package state.ma.us.OMSBulk.writer;

import java.util.ArrayList;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.jdbc.core.JdbcTemplate;



import state.ma.us.OMSBulk.util.OMSDaoImpl;
import state.ma.us.OMSBulk.util.OMSDaoInterface;
import state.ma.us.OMSBulk.vo.OrganizationVO;


public class CustomOrgWriter implements ItemWriter<String> {

    private JdbcTemplate jdbcTemplate;  

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
        this.jdbcTemplate = jdbcTemplate;  
    }
    
    @Override
	public void write(List<? extends String> org) throws Exception {
    	OMSDaoInterface odi=new OMSDaoImpl(jdbcTemplate);
		ArrayList ar=new ArrayList(org);
		for(Object or:ar){
			OrganizationVO o=(OrganizationVO) or;
			if(o.getIsValidorg()){
				if(!o.getVgOrgId().equals("")){
					o.setOrgId(odi.getOrgIdFromEHSId(o.getVgOrgId()));
					String updateResult=odi.updateOrganization(o);
					if(updateResult.contains("Success")){
						System.out.println("updateOrganization is successful");
					}
				}else{
					System.out.println("No VGOrgId found. Will create org now!!!");
					o.setOrgId(odi.getOrgIdFromSequence());
					System.out.println("OrgId to be used for new org :: "+o.getOrgId());
					String createResult=odi.createOrganization(o);
					if(createResult.contains("Success")){
						System.out.println("createOrganization is successful");
					}
				}
			}else{
				String createInvalidResult=odi.createInvalidOrganization(o);
				if(createInvalidResult.contains("Success")){
					System.out.println("createOrganization is successful");
				}
			}
		}
	}
			
			//}

}
