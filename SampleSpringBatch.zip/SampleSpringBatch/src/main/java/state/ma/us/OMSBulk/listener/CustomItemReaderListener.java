package state.ma.us.OMSBulk.listener;
import org.springframework.batch.core.ItemReadListener;

import state.ma.us.OMSBulk.vo.OrganizationVO;

public class CustomItemReaderListener  implements ItemReadListener<OrganizationVO> {

	@Override
	public void beforeRead() {
		System.out.println("CustomItemReaderListener - beforeRead");
	}

	@Override
	public void afterRead(OrganizationVO item) {
		System.out.println("CustomItemReaderListener - afterRead :: "+item.getLegalName());
		
	}

	@Override
	public void onReadError(Exception ex) {
		System.out.println("CustomItemReaderListener - onReadError");
	}


}
