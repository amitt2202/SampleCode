package state.ma.us.OMSBulk;

import java.util.Date;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


/**
 * Run the batch job
 *
 */
public class App {

	public static void main(String[] args) {

		String[] springConfig  = 
			{	
				"spring/batch/jobs/oms-bulk-job.xml" 
			};
		
		ApplicationContext context = 
				new ClassPathXmlApplicationContext(springConfig);
		
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		Job job = (Job) context.getBean("OMSBulkOrgJob");
		System.out.println(""+job.getName());
		try {
			JobParametersBuilder builder = new JobParametersBuilder();
			builder.addDate("date", new Date());
			//launcher.run(job, builder.toJobParameters());
			//JobExecution execution = jobLauncher.run(job, new JobParameters());
			JobExecution execution = jobLauncher.run(job, builder.toJobParameters());
			System.out.println("Exit Status : " + execution.getStatus());

		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("Done");

	}
}
