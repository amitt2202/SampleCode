package com.poc.bean;

import java.io.Serializable;

import java.util.ArrayList;

import java.util.List;
import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.ADFContext;
import oracle.binding.AttributeBinding;
import oracle.binding.BindingContainer;
import oracle.binding.OperationBinding;

import javax.faces.model.SelectItem;

import oracle.adf.view.rich.component.rich.input.RichSelectOneListbox;
import oracle.adf.view.rich.context.AdfFacesContext;
import oracle.adf.view.rich.render.ClientEvent;

public class AutoSuggestBean implements Serializable{
    private ArrayList<SelectItem> empList = null;
    private RichSelectOneListbox empSuggestList;
    String srchString="";

    public AutoSuggestBean() {
    }

    public void setEmpSuggestList(RichSelectOneListbox empSuggestList) {
        this.empSuggestList = empSuggestList;
    }

    public RichSelectOneListbox getEmpSuggestList() {
        return empSuggestList;
    }

    public void setEmpList(ArrayList<SelectItem> empList) {
        this.empList = empList;
    }

    public ArrayList<SelectItem> getEmpList() {
        if (empList == null){
            empList = new ArrayList<SelectItem>();
            List<String> filteredList = null;
            filteredList = filteredValues(srchString, false);
            empList = populateList(filteredList);
        }       
        return empList;
    }

    public void selectEmpList(ClientEvent clientEvent) {
        srchString = (String)clientEvent.getParameters().get("filterString");
        List<String> filteredList = filteredValues(srchString, true);
        empList = populateList(filteredList);
        AdfFacesContext.getCurrentInstance().addPartialTarget(empSuggestList);
    }

    private ArrayList<SelectItem> populateList(List<String> filteredList) {
        ArrayList<SelectItem> _list = new ArrayList<SelectItem>();
        for(String suggestString : filteredList){
            SelectItem si = new SelectItem();
            si.setValue(suggestString);
            si.setLabel(suggestString);
            _list.add(si);
        }
      return _list;
    }

    public BindingContainer getBindings() {
        return BindingContext.getCurrent().getCurrentBindingsEntry();
    }

    private List<String> filteredValues(String srchString, boolean b) {
        List<String> empList = new ArrayList<String>();
        OperationBinding operationBinding =getBindings().getOperationBinding("queryEmployee");
        operationBinding.getParamsMap().put("filter", srchString);
        operationBinding.getParamsMap().put("doFilterInMemory", b);
        Object deleteAppRoleResult = operationBinding.execute();
        if (!operationBinding.getErrors().isEmpty()) {
            System.out.println("no error");
        }else{
            empList=(List<String>)deleteAppRoleResult;
        }
        return empList;
    }
}
