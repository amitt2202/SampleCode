package com.test.rest;


import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.PathParam;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;


@Path("/PlayerService")
public class PlayerService {
	PlayerDao playerDao = new PlayerDao();
    private static final String SUCCESS_RESULT="<result>success</result>";
    private static final String FAILURE_RESULT="<result>failure</result>";
	@GET
	@Path("/player")
	@Produces(MediaType.APPLICATION_XML)
	public List<Player> getTrackInJSON() {
		/*List<Person> listPerson = new ArrayList<>();*/
		return playerDao.getAllPlayer();
	}

   @GET
   @Path("/player/{playerid}")
   @Produces(MediaType.APPLICATION_XML)
   public Player getUser(@PathParam("playerid") int playerid){
      return playerDao.getPlayer(playerid);
   }
   @PUT
   @Path("/updatePlayer")
   @Produces(MediaType.APPLICATION_XML)
   @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
   public String updatePlayer(@FormParam("id") int id,
      @FormParam("name") String name,
      @FormParam("sports") String sports,
      @Context HttpServletResponse servletResponse) throws IOException{
	   Player app = new Player(id, name, sports);
      int result = playerDao.updatePlayer(app);
      if(result == 1){
         return SUCCESS_RESULT;
      }
      return FAILURE_RESULT;
   }
   

   @POST
   @Path("/createPlayer")
   @Produces(MediaType.APPLICATION_XML)
   @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
   public String createPlayer(@FormParam("id") int id,
      @FormParam("name") String name,
      @FormParam("sports") String sports,
      @Context HttpServletResponse servletResponse) throws IOException{
	   Player app = new Player(id, name, sports);
      int result = playerDao.createPlayer(app);
      if(result == 1){
         return SUCCESS_RESULT;
      }
      return FAILURE_RESULT;
   }
}
