package com.test.rest;


import javax.ws.rs.PathParam;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;



@Path("/PlayerService")
public class PlayerService {
	PlayerDao playerDao = new PlayerDao();
	@GET
	@Path("/player")
	@Produces(MediaType.APPLICATION_XML)
	public List<Player> getTrackInJSON() {
		/*List<Person> listPerson = new ArrayList<>();
		Person p1 = new Person();
		p1.setId(1);;
		p1.setName("name1");
		Person p2 = new Person();
		p2.setId(2);
		p2.setName("name2");
		listPerson.add(p1);
		listPerson.add(p2);
		return listPerson;*/
		/*List<Player> playerList =  new ArrayList<Player>();
		 Player user1 = new Player(1, "Shahid", "Cricket");
    	 Player user2 = new Player(2, "Messy", "Soccer");
    	 Player user3 = new Player(3, "Roger", "Tennis");
    	 Player user4 = new Player(3, "Brady", "Football");
    	 playerList = new ArrayList<Player>();
    	 playerList.add(user1);
    	 playerList.add(user2);
    	 playerList.add(user3);
    	 playerList.add(user4);
		   System.out.print("Added 4 players");
	      return playerList;*/
		return playerDao.getAllPlayer();
	}

	   @GET
	   @Path("/player/{playerid}")
	   @Produces(MediaType.APPLICATION_XML)
	   public Player getUser(@PathParam("playerid") int playerid){
	      return playerDao.getPlayer(playerid);
	   }
}
