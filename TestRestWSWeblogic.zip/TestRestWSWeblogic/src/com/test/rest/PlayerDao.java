package com.test.rest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;





public class PlayerDao {
	 public List<Player> getAllPlayer(){
	      List<Player> playerList = null;
	      try {
	         File file = new File("Player.dat");
	         if (!file.exists()) {
	        	 System.out.println("No File found. Adding players....");
	        	 Player user1 = new Player(1, "Shahid", "Cricket");
	        	 Player user2 = new Player(2, "Messy", "Soccer");
	        	 Player user3 = new Player(3, "Roger", "Tennis");
	        	 Player user4 = new Player(3, "Brady", "Football");
	        	 playerList = new ArrayList<Player>();
	        	 playerList.add(user1);
	        	 playerList.add(user2);
	        	 playerList.add(user3);
	        	 playerList.add(user4);
	            savePlayerList(playerList);		
	         }
	         else{
	            FileInputStream fis = new FileInputStream(file);
	            System.out.println("File path :  "+file.getAbsolutePath());
	            ObjectInputStream ois = new ObjectInputStream(fis);
	            playerList = (List<Player>) ois.readObject();
	            ois.close();
	         }
	      } catch (IOException e) {
	         e.printStackTrace();
	      } catch (ClassNotFoundException e) {
	         e.printStackTrace();
	      }		
	      return playerList;
	   }



	   public Player getPlayer(int id){
	      List<Player> players = getAllPlayer();
	      for(Player player: players){
	         if(player.getId() == id){
	            return player;
	         }
	      }
	      return null;
	   }


	   private void savePlayerList(List<Player> playerList){
	      try {
	         File file = new File("Player.dat");
	         FileOutputStream fos;

	         fos = new FileOutputStream(file);

	         ObjectOutputStream oos = new ObjectOutputStream(fos);		
	         oos.writeObject(playerList);
	         oos.close();
	      } catch (FileNotFoundException e) {
	         e.printStackTrace();
	      } catch (IOException e) {
	         e.printStackTrace();
	      }
	   }
}
