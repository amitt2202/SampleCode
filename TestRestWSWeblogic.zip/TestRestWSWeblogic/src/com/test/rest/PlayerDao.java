package com.test.rest;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class PlayerDao {
	 @SuppressWarnings("unchecked")
	public List<Player> getAllPlayer(){
	      List<Player> playerList = new ArrayList<Player>();
	      System.out.println("aa");
		  Session session =null;
		  try {
			 Configuration c = new Configuration();
			 c.configure("/com/test/rest/hibernate.cfg.xml");
			 System.out.println("bb");
			 SessionFactory sf = c.buildSessionFactory();
			 session = sf.openSession();
			 System.out.println("cc");
			 Transaction tx = null;
			 System.out.println("dd");
		     tx = session.beginTransaction();
		     System.out.println("ee");
		     List app = session.createQuery("FROM Player").list(); 
		     for (Iterator iterator = app.iterator(); iterator.hasNext();){
		    	 Player a = (Player) iterator.next(); 
		        System.out.print("Id: " + a.getId()); 
		        System.out.print("First Name: " + a.getName()); 
		        System.out.println("  Description " + a.getSports());
		        playerList.add(a);
		     }
		     tx.commit();
		  } catch (Exception e) {
			  System.out.print("Errr             "); 
		     e.printStackTrace(); 
		  } finally {
		     session.close(); 
		  }
		  System.out.println("Exiting  PlayerDao.getAllPlayer with : "+playerList.size());
	      return playerList;
	   }



	   public Player getPlayer(int id){
		   Player a=new Player();
		   List<Player> playerList = new ArrayList<Player>();
			Session session =null;
			try {
				 Configuration c = new Configuration();
				 c.configure("/com/test/rest/hibernate.cfg.xml");
				 System.out.println("bb");
				 SessionFactory sf = c.buildSessionFactory();
				 session = sf.openSession();
				Transaction tx = null;
				tx = session.beginTransaction();
			    List app = session.createQuery("FROM Player  A WHERE A.id = "+id).list();
			    for (Iterator iterator = app.iterator(); iterator.hasNext();){
			        a = (Player) iterator.next();
			     }
			     tx.commit();
			  } catch (Exception e) {
				  System.out.print("Errr             "); 
			     e.printStackTrace(); 
			  } finally {
			     session.close(); 
			  }
			  return a;
	   }
	   public int updatePlayer(Player player) {
			  int retInt=updatePlayerInDB(player) ;
			  return retInt;
		}

		private int updatePlayerInDB(Player vo) {
		   int retInt=0;
		   Session session =null;
		   Transaction tx = null;
		   try {
			  Configuration c = new Configuration();
			  c.configure("/com/test/rest/hibernate.cfg.xml");
			  SessionFactory sf = c.buildSessionFactory();
			  session = sf.openSession();
			  tx = session.beginTransaction();
			  Player playerVO = (Player)session.get(Player.class, vo.getId()); 
			  playerVO.setName(vo.getName());
			  playerVO.setSports(vo.getSports());
			  session.update(playerVO); 
	          tx.commit();
	          retInt=1;
		     }catch (HibernateException e) {
	            if (tx!=null){
	               tx.rollback();
	            }
	            e.printStackTrace(); 
		      } finally {
		         session.close(); 
		      }
		 return retInt;
		}
		
		public int createPlayer(Player vo) {
			  int retInt=insertPlayerInDB(vo) ;
			  return retInt;
		}

		private int insertPlayerInDB(Player vo) {
		   int retInt=0;
		   Session session =null;
		   Transaction tx = null;
		   try {
			  Configuration c = new Configuration();
			  c.configure("/com/test/rest/hibernate.cfg.xml");
			  SessionFactory sf = c.buildSessionFactory();
			  session = sf.openSession();
			  tx = session.beginTransaction();
			  Player appVO = new Player(vo.getId(), vo.getName(), vo.getSports());
			  session.save(appVO); 
	          tx.commit();
	     	  retInt=1;
		     }catch (HibernateException e) {
	            if (tx!=null){
	               tx.rollback();
	            }
	            e.printStackTrace(); 
		      } finally {
		         session.close(); 
		      }
		 return retInt;
		}

}
