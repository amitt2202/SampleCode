package com.test.rest;

import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@XmlRootElement
public class Player implements Serializable {  
	private int id;
	private String name;
	private String sports;
	
	public Player(int id, String name, String sports){
	      this.id = id;
	      this.name = name;
	      this.sports = sports;
	   }

		public int getId() {
		return id;
	}

	public void setSports(String sports) {
		this.sports = sports;
	}

		public Player(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public Player() {
		super();
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSports() {
		return sports;
	}
}