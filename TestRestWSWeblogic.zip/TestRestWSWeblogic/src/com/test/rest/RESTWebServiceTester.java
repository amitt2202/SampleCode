package com.test.rest;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;



 

public class RESTWebServiceTester {

	   private Client client;
	   
	   private String REST_SERVICE_URL = "http://170.63.122.58:7001/TestRestWSWeblogic/rest/PlayerService";
	   private static final String SUCCESS_RESULT="<result>success</result>";
	   private static final String PASS = "pass";
	   private static final String FAIL = "fail";

	   private void init(){
	      this.client = ClientBuilder.newClient();
	   }

	   public static void main(String[] args){
		   RESTWebServiceTester tester = new RESTWebServiceTester();
	      //initialize the tester
	      tester.init();
	      //test get all app Web Service Method
	      tester.testGetAllApplications();
	      //test get app Web Service Method
	      tester.testGetApplication(2);
	      //test update app Web Service Method
	      tester.testUpdateApplication();
	      tester.testAddApplication();
	   }
	   //Test: Get list of all users
	   //Test: Check if list is not empty
	   private void testGetAllApplications(){
	      GenericType<List<Player>> list = new GenericType<List<Player>>() {};
	      List<Player> apps = client
	         .target(REST_SERVICE_URL+"/player")
	         .request(MediaType.APPLICATION_XML)
	         .get(list);
	      String result = PASS;
	      if(apps.isEmpty()){
	         result = FAIL;
	      }
	      for(Player a:apps){
	    	  System.out.println("Result: Id:" + a.getId()+"  Name:  " +a.getName()+" Sports: "+a.getSports());
	      }
	      System.out.println("Test case name: testGetAllApplications, Result: " + result );
	   }
	   
	   private void testGetApplication(int id){
		   Player sampleApp = new Player();
		   sampleApp.setId(id);
	
		   Player app = client
	    	 .target(REST_SERVICE_URL+"/player")
	         .path("/{playerId}")
	         .resolveTemplate("playerId", id)
	         .request(MediaType.APPLICATION_XML)
	         .get(Player.class);
	      String result = FAIL;
	      if(sampleApp != null && sampleApp.getId() == app.getId()){
	         result = PASS;
	      }
	      System.out.println("Result: Id:" + app.getId()+"  Name:  " +app.getName()+" Sports: "+app.getSports());
	      System.out.println("Test case name: testGetApplication, Result: " + result );
	   }
	   
	   //Test: Update User of id 1
	   //Test: Check if result is success XML.
	   private void testUpdateApplication(){
	      Form form = new Form();
	      form.param("id", "1");
	      form.param("name", "Sahil");
	      form.param("sports", "sports");

	      String callResult = client
	    	 .target(REST_SERVICE_URL+"/updatePlayer")
	         .request(MediaType.APPLICATION_XML)
	         .put(Entity.entity(form,
	            MediaType.APPLICATION_FORM_URLENCODED_TYPE),
	            String.class);
	      String result = PASS;
	      if(!SUCCESS_RESULT.equals(callResult)){
	         result = FAIL;
	      }

	      System.out.println("Test case name: testUpdateApplication, Result: " + result );
	   }
	  
	   private void testAddApplication(){
		   Form form = new Form();
		      form.param("id", "4");
		      form.param("name", "TestAdd");
		      form.param("sports", "Testsports");

	      String callResult = client
	         .target(REST_SERVICE_URL+"/createPlayer")
	         .request(MediaType.APPLICATION_XML)
	         .post(Entity.entity(form,
	            MediaType.APPLICATION_FORM_URLENCODED_TYPE),
	            String.class);
	   
	      String result = PASS;
	      if(!SUCCESS_RESULT.equals(callResult)){
	         result = FAIL;
	      }

	      System.out.println("Test case name: testAddApplication, Result: " + result );
	   }
}
