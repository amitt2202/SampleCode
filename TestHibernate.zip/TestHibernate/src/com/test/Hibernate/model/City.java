package com.test.Hibernate.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * City POJO class.
 * Represents the City table
 * 
 * 
 */
@XmlRootElement(name = "City")
public class City {

	private int id;
	
	private String name;

	public City(int id,String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public City() {}

	
	public int getId() {
		return id;
	}
	@XmlElement
	public void setId(int id) {
		this.id = id;
	}
	
	
	public String getName() {
		return name;
	}
	@XmlElement
	public void setName(String name) {
		this.name = name;
	}
}
