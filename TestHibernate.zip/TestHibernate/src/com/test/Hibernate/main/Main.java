package com.test.Hibernate.main;

import com.test.Hibernate.dao.CityDAO;




public class Main {

	public static void main(String[] args) {
		
		CityDAO cityDAO = new CityDAO();
		
		/*cityDAO.saveCity(1,"New York");
		cityDAO.saveCity(2,"Rio de Janeiro");
		cityDAO.saveCity(3,"Tokyo");
		cityDAO.saveCity(4,"London");

		cityDAO.listCities();*/
		
		cityDAO.updateCity(3, "Delhi");
		
		//cityDAO.deleteCity(cityId3);
		
		//cityDAO.listCities();
	}
}
