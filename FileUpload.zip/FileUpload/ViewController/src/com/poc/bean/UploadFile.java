package com.poc.bean;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import org.apache.myfaces.trinidad.model.UploadedFile;


public class UploadFile {
    private UploadedFile file;
    private InputStream inputstream;
    private String fileName;
    public UploadFile() {
    }

    public void selectFile_vcl(ValueChangeEvent event) {
        UploadedFile file = (UploadedFile) event.getNewValue();
        if (file != null)
        {
          fileName=file.getFilename();
          try {
                inputstream=file.getInputStream();
          } catch (IOException e) {
                e.printStackTrace();
          }
        }
    }
    
    public void uploadFileAction(ActionEvent actionEvent) {
        OutputStream outputStream = null;
        try{
            outputStream = new FileOutputStream(new File("C:\\JDeveloper\\mywork\\uploadedFiles\\"+fileName));
            int read = 0;
            byte[] bytes = new byte[1024];
            while ((read = inputstream.read(bytes)) != -1) {
                    outputStream.write(bytes, 0, read);
            }
            System.out.println("Done!");
        }catch(Exception e){
            e.printStackTrace();
        } finally {
                if (inputstream != null) {
                        try {
                                inputstream.close();
                        } catch (IOException e) {
                                e.printStackTrace();
                        }
                }
                if (outputStream != null) {
                        try {
                                // outputStream.flush();
                                outputStream.close();
                        } catch (IOException e) {
                                e.printStackTrace();
                        }
    
                }
        }
    }
}
