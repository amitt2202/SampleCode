package my.portal.application.view;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.util.Enumeration;
import java.util.ListResourceBundle;
import java.util.Properties;

public class TestResBundle extends ListResourceBundle {

    public TestResBundle() {
        super();
    }
    protected Object[][] getContents() {
        Object[][] contents = null;
        FileInputStream fInStream = null;
        try {
            //  File file = new File("/test/HppResBundle.properties");
            //File file = new File("/app/Resourcebundle/HppResBundle.properties");
            File file = new File(System.getProperty("AIMSPROP_PATH"));
            Properties prop = new Properties();
            //load a properties file
            fInStream = new FileInputStream(file);
            prop.load(fInStream);
            Enumeration propKeys = prop.keys();
            System.out.println("Property size : " + prop.size());
            contents = new Object[prop.size()][2];
            int i = 0;
            while (propKeys.hasMoreElements()) {
                String key = (String)propKeys.nextElement();
                String value = prop.getProperty(key);
                //System.out.println("Key  " + key + " -> : " + value);
                contents[i][0] = key;
                contents[i][1] = value;
                i++;
            }
        } catch (IOException ioException) {
           System.out.println("ioException "+ioException);

        } catch (Exception exception) {
            System.out.println("Exception"+exception);
        } finally {
            try {
                fInStream.close();
            } catch (Exception e) {
                System.out.println("Exception "+e);
            }
        }
        return contents;
    }

}
