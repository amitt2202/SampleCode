package my.portal.application.bean;

import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import my.portal.application.view.TestResBundle;

public class TestBean {
    public TestBean() {
        super();
    }

    public void testbutton_ActionListenmer(ActionEvent actionEvent) {
        ResourceBundle rs = new TestResBundle();
        String butoon_message = rs.getString("butoon_message");
        FacesContext facesContext = FacesContext.getCurrentInstance();
        facesContext.addMessage("button message",
                                new FacesMessage(FacesMessage.SEVERITY_INFO,
                                                 "test",
                                                 butoon_message));
        
    }
}
